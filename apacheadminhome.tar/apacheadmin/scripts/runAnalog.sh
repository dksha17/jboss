#!/bin/ksh
# =====================================================================================
# Copyright Sears Holdings Corporation, 2010
# All rights reserved. Licensed Materials Property of Sears Holdings Corporation
#
# Author:  rdelara
# Date:    August 2010
#
# Description: Excute the anlaog scripts that exist
#
# History of revisions
# 0.0  8/2010  rdelara  Initial release
# =====================================================================================

# ===========================
# Source the function library
# ===========================
. ~apacheadmin/scripts/ewts_functions

# =========================
# Define the Usage function
# =========================
Usage(){
print "
This script is used to excute the analog scripts that exists.
The script has no input requirements"
exit
}


# ============================
# Check for input parameter(s)
# ============================
if [ ${#@} -ne 0 ];then
  Usage
fi


# ===================
# Set local variables
# ===================
analogDir=/home/apacheadmin/analog/config
analogLogDir=/home/apacheadmin/analog/logs


# ===========================
# Execute analog perl scripts
# ===========================
for portNumber in `ls -1 $analogDir/*.cfg |cut -d- -f2|cut -d. -f1`
do
# name=`basename $analogScript .pl`
 analogLog=${analogLogDir}/${portNumber}.log
 ${analogDir}/runAnalog.pl ${portNumber} >> ${analogLog} 2>&1

done

exit
