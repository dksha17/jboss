#!/bin/ksh
#######################################################################################################
#  Asking the user to type the userid, password and jvmname
######################################################################################################
JBOSS_HOME=/appl/software/wildfly8.2
echo "Please enter the username."
read RESPONSE
username=$RESPONSE

echo "Please enter the password. examaple:test1@adm, it needs more than 8 characters, at least one numeric, and one non-regular character like @"
read RESPONSE
password=$RESPONSE

echo "Please enter the jvm name the admin password for"
read RESPONSE
jvmname=$RESPONSE
echo "username: $username, password: $password, jvmname:$jvmname ">>/home/jboss/passwords
$JBOSS_HOME/bin/add-user.sh $username $password
lastline=`cat $JBOSS_HOME/standalone/configuration/mgmt-users.properties|grep "\$username" |tail -1`
echo "Write into $jvmname mgmt-users.properties file"
echo -e $lastline >>$JBOSS_HOME/$jvmname/configuration/mgmt-users.properties
